body {
    font-family: Arial, sans-serif;
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 20px;
}

.container {
    background-color: #444;
    padding: 20px;
    border-radius: 10px;
    max-width: 600px;
    margin: auto;
}

header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
}

.logo {
    width: 50px;
}

.theme-selector {
    color: #fff;
}

h1 {
    color: gold;
}

button {
    background-color: orange;
    border: none;
    padding: 15px;
    font-size: 18px;
    border-radius: 5px;
    cursor: pointer;
    color: black;
    margin: 5px;
}

button:hover {
    background-color: gold;
}

.navigation {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 20px;
}

.nav-middle {
    display: flex;
    justify-content: center;
    width: 100%;
}

.volume-channel, .media-playback, .input-source {
    display: flex;
    justify-content: space-around;
    margin-top: 20px;
}

.channel-input {
    margin-top: 20px;
}

input[type="number"] {
    padding: 10px;
    font-size: 16px;
    border-radius: 5px;
    border: none;
}

.favorites-history {
    margin-top: 30px;
}

.favorites-history ul {
    list-style-type: none;
    padding: 0;
}

.voice-control {
    margin-top: 30px;
}

.help-section {
    margin-top: 30px;
    color: lightgray;
}

.help-section a {
    color: orange;
    text-decoration: none;
}
